AVAILABLE_MODELS = {
    "vila_internal": "VILA",
}
